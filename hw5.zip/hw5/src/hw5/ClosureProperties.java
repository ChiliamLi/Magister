package hw5;

public class ClosureProperties {
    
//All graph properties can be found in graph.java

    // Inputs our matched graph, and calculates Homophily 
    public float homophily (StudentTutorGraph g) {
        return 0; //TODO
    }
    //Calculates clustering coefficient
    public float clusteringCoefficients (StudentTutorGraph g) {
        return 0; //TODO
    }
    //Checks if focal closure is satisfied
    public boolean focalClosure (StudentTutorGraph g) {
        return true; //TODO
    }
    //Checks if membership closure is satisfied
    public boolean membershipClosure (StudentTutorGraph g) {
        return true; //TODO
    }
    //Checks if triadic closure is satisfied
    public boolean triadicClosure (StudentTutorGraph g) {
        return true; //TODO
    }
    //Checks to see if our tutor/student graph is a bipartite graph
    public boolean BipartiteMatching (StudentTutorGraph g) {
        return true; //TODO
    }
    
    //Calculates the number of subtrees and finds a numerical representation for how connected
    //our graph is (basically how interconnected our tutor/student group is)
    public boolean DFSConnectedness (StudentTutorGraph g) {
        return true; //TODO
    }
    
}
