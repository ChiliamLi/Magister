package hw5;

public enum Course {
    MATH, READING, WRITING, SCIENCE, HISTORY
}
